# toursim-event-mangement
a web-based system for manging tourism events.
